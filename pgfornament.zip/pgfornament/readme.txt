2012/03/01

This archive contains :

-- this document;
-- the documentation beta (0.1) of  pgfornament (0.1);
-- the package  pgfornament.sty;
-- the package tikzrput.sty;
-- the folder vectorian; (with 89 elements)
-- the folder am; (with 2 elements) 
-- the folder examples;
-- the file pgflibraryvectorian.code.tex;
-- the file pgflibraryam.code.tex.